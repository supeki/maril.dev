$Id: README 9004 2004-10-17 13:48:57Z hartman $

README for the VLC media player
===============================

ABOUT-NLS          - Notes on the Free Translation Project.
AUTHORS            - Main VLC authors.
COPYING            - The GPL license.
ChangeLog          - The vlc ChangeLog.
FAQ                - Commonly asked questions.
HACKING            - Hacking vlc.
INSTALL            - Installation instructions.
INSTALL.win32      - Installation instructions for the Win32 version of vlc.
README             - This file.
README.MacOSX.rtf  - Information specific to the MacOS X port.
THANKS             - All VLC contributors.
doc/               - Miscellaneous documentation.

Resources
=========

The VideoLAN web site: http://www.videolan.org/
Documentation and support: http://w.videolan.org/support/
Forums: http://forum.videolan.org/
The Developers site: http://developers.videolan.org/vlc/

